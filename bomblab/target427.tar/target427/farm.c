/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_462()
{
    return 3284633928U;
}

void setval_442(unsigned *p)
{
    *p = 2425378897U;
}

unsigned addval_163(unsigned x)
{
    return x + 2462550344U;
}

unsigned addval_287(unsigned x)
{
    return x + 2425393240U;
}

void setval_385(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_248(unsigned x)
{
    return x + 2496104776U;
}

unsigned getval_226()
{
    return 2425393272U;
}

void setval_247(unsigned *p)
{
    *p = 3243783139U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_474(unsigned x)
{
    return x + 3682913921U;
}

unsigned getval_436()
{
    return 3286272344U;
}

unsigned getval_336()
{
    return 3674787467U;
}

unsigned getval_149()
{
    return 3353381192U;
}

void setval_100(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_300()
{
    return 3523789441U;
}

void setval_449(unsigned *p)
{
    *p = 3264270729U;
}

void setval_428(unsigned *p)
{
    *p = 3526938265U;
}

unsigned addval_395(unsigned x)
{
    return x + 3286273352U;
}

unsigned getval_338()
{
    return 3465128236U;
}

void setval_378(unsigned *p)
{
    *p = 3221799565U;
}

unsigned addval_327(unsigned x)
{
    return x + 3221799560U;
}

void setval_254(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_250()
{
    return 3653422729U;
}

unsigned getval_495()
{
    return 3281047949U;
}

void setval_448(unsigned *p)
{
    *p = 3224949129U;
}

unsigned getval_133()
{
    return 3286272328U;
}

unsigned getval_498()
{
    return 2425406121U;
}

void setval_420(unsigned *p)
{
    *p = 3374371209U;
}

unsigned getval_377()
{
    return 3373846153U;
}

void setval_177(unsigned *p)
{
    *p = 2425409177U;
}

unsigned getval_175()
{
    return 3674788297U;
}

unsigned addval_132(unsigned x)
{
    return x + 3286272072U;
}

unsigned getval_257()
{
    return 3353381192U;
}

unsigned addval_225(unsigned x)
{
    return x + 3281113481U;
}

unsigned addval_499(unsigned x)
{
    return x + 3284306422U;
}

void setval_312(unsigned *p)
{
    *p = 2428672486U;
}

unsigned getval_455()
{
    return 3375943305U;
}

unsigned getval_403()
{
    return 3229929864U;
}

void setval_339(unsigned *p)
{
    *p = 3284306306U;
}

unsigned getval_323()
{
    return 3232023177U;
}

unsigned getval_187()
{
    return 3247493513U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
